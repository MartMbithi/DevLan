#!/usr/bin/python

# Import library
import getpass
import re
import signal
import socket
import sys
import telnetlib
import time

# Function to stop the program
def close_program(signal, frame):
	print("End of script")
	sys.exit(0)

# Function checking IP address syntax
def is_valid_ip(ip):
	result = re.match(r"^(\d{1,3}\.){3}\d{1,3}$", ip)
	return bool(result)

# Call function when system want to stop (command ctrl+c)
signal.signal(signal.SIGINT, close_program)

# VARIABLE SET
tftp_server = "192.168.122.93" 
timeout = 120  
log_file = "log.txt" 
hosts_file = "devices.txt"
telnet_port = 23 

# Account Parameters
user = raw_input("Enter your remote account: ") 
password = getpass.getpass() 

# Other Variable
successful = 0
failure = 0

# Create an output file for the results
log = open(log_file, "w") 

# Load input file
try :
	input_file = open(hosts_file, "r") # Open file in read mode
	hosts = input_file.readlines()
	input_file.close()
except IOError:
	print "Error opening file"
	sys.exit(0)

# Loop on all lines in input file
for ip_address in hosts:
	ip_address=ip_address[:len(ip_address) - 1] 
	if is_valid_ip(ip_address):
		try :
			telnet = telnetlib.Telnet(ip_address,telnet_port,timeout) 

			print time.strftime('%d/%m/%y %H:%M:%S',time.localtime()) + " Running on : " + ip_address # For user information

			
			telnet.read_until("***************************************************************",timeout) 
			telnet.read_until("***************************************************************",timeout)  
			telnet.write('\x19' + '\n') # Order to simulate keybord Ctrl+Y, go to see => http://donsnotes.com/tech/charsets/ascii.html
			telnet.write('\t') # Order to simulate tabulation key
			telnet.write(user + "\n") # Enter username
			telnet.write(password + "\n") # Enter password

			# Function to retrieve the name of the switch
			host_name = telnet.read_until("#",timeout)
			for iteration, letter in enumerate(reversed(host_name)):
				if letter == "\n":
					host_name = host_name[(len(host_name) - iteration):(len(host_name) - 1)]
					break

			telnet.write("copy running-config tftp address " + tftp_server + " filename " + ip_address + "-" + host_name + "\n") # Switch command for saving configuration in tftp
			telnet.read_until("ACG configuration generation completed",timeout) # Backup successful indication
			telnet.close() # End of telnet session on the host

			# Write for log file
			log.write(time.strftime('%d/%m/%y %H:%M:%S',time.localtime()) + " " + ip_address + " " + host_name + " : Successful" + "\n")
			print time.strftime('%d/%m/%y %H:%M:%S',time.localtime()) + " Successful" # For user information
			successful += 1

		except socket.error, error:
			log.write(time.strftime('%d/%m/%y %H:%M:%S',time.localtime()) + " " + ip_address + " Failure - " + str(error) + "\n")
			print time.strftime('%d/%m/%y %H:%M:%S',time.localtime()) + " Failure on : " + ip_address # For user information
			failure += 1

# End of script
print "End of script"
log.write("\n")
log.write(time.strftime('%d/%m/%y %H:%M:%S',time.localtime()) + " : End of script" + "\n")
log.write("Number of Failures : " + str(failure) + "\n")
log.write("Number of Successful : " + str(successful) + "\n")
sys.exit(0)

#markov_chains

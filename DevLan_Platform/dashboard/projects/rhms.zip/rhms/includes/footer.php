<div class="footer">
		<div class="container">
			<div class="col-md-4 footer-grids">
				<h3>Review</h3>
				<p>Sed ut turpis elit ullamcorper in auctor non, accumsan vel lacus nulla auctor cursus nunc. Maecenas ultricies dolor in urna tempus, id egestas erat finibus  interdum lectus eget scelerisque.</p>
			</div>
			<div class="col-md-3 footer-grids">
				<h3>Contact Me</h3>
				<p>123 NewYork City USA.<br>
					<span>Office: 908-0000</span>
				</p>
				<div class="footer-bottom">
					<a href="#"><span>Facebook</span></a>
					<a href="#"><span>Pinterest</span></a>
					<a href="#"><span>LinkedIn </span></a>
					<a href="#"><span>Behance</span></a>
				</div>
			</div>
			<div class="col-md-5 footer-grids">
				<h3>Flickr</h3>
				<a  class="footer-img" href="single.html"> <img src="images/f1.jpg" alt=""/></a>
				<a class="footer-img" href="single.html"> <img src="images/f2.jpg" alt=""/></a>
				<a class="footer-img" href="single.html"> <img src="images/f3.jpg" alt=""/></a>
			</div>
			<div class="clearfix"> </div>
			<div class="footer-copy">
				<p>© 2019 Rental and RealEstate Management System  All rights reserved | a <a href="https://martdev.info">MartDevelopers </a>Production</p>
			</div>
		</div>
	</div>
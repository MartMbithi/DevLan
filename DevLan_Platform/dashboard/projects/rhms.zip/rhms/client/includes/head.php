<nav class="navbar navbar-expand navbar-dark">
				<a class="sidebar-toggle d-flex mr-2">
            <i class="hamburger align-self-center"></i>
          </a>

				<form class="form-inline d-none d-sm-inline-block">
					<input class="form-control form-control-lite" type="text" placeholder="Search...">
				</form>

				<div class="navbar-collapse collapse">
					<ul class="navbar-nav ml-auto">
						
					<li class="nav-item dropdown ml-lg-2">
							<a class="nav-link dropdown-toggle" href="#" id="userDropdown" data-toggle="dropdown">
                <i class="align-middle fas fa-bell"></i>
              </a>
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
								<a class="dropdown-item" href="client-messages.php"><i class="align-middle mr-1 fas fa-fw fa-envelope"></i>Messages</a>
								</div>
						</li>

						<li class="nav-item dropdown ml-lg-2">
							<a class="nav-link dropdown-toggle" href="#" id="userDropdown" data-toggle="dropdown">
                <i class="align-middle fas fa-cogs"></i>
              </a>
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
								<a class="dropdown-item" href="client-profile.php"><i class="align-middle mr-1 fas fa-fw fa-user"></i>Profile</a>
								<a class="dropdown-item" href="client-signout.php"><i class="align-middle mr-1 fas fa-fw fa-arrow-alt-circle-right"></i> Sign out</a>
							</div>
						</li>
					</ul>
				</div>

			</nav>
<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-8 text-left">
							
						</div>
						<div class="col-8 text-right">
							<p class="mb-0">
								RentalHouse Management System &copy;<?php echo date ("Y");?> - Powered By <a href="https://martdev.info">MartDevelopers</a>
							</p>
						</div>
					</div>
				</div>
			</footer>
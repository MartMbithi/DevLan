<?php
$dbuser="martdev1_root";
$dbpass="Martinez@";
$host="localhost";
$db="martdev1_rhms";
$mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>

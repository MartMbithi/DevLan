<?php include("includes/header.php")?>
<!--//end-smoth-scrolling-->
</head>
<body>
	<!--banner-->
	<div  id="home" class="banner about-banner">
		<div class="banner-info">
			<!--navigation-->
			<div class="top-nav">
				<nav>
					<div class="container">
						<div class="navbar-header logo">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<h1><a href="index.php">Rental</a></h1>
						</div>
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-right">
								<li><a href="index.php" class="link-kumya"><span data-letters="Home">Home</span></a></li>
								<li><a href="about.php" class="link-kumya"><span data-letters="About">About</span></a></li>	
								<li><a href="portfolio.php" class="link-kumya"><span data-letters="Portfolio">Portfolio</span></a></li>
								<li><a href="codes.php" class="link-kumya"><span data-letters="Short Codes">Short Codes</span></a></li>
								<li><a href="blog.php" class="link-kumya active"><span data-letters="Blog">Blog</span></a></li>		
								<li><a href="contact.php" class="link-kumya"><span data-letters="Contact">Contact</span></a></li>
								<li><a href="client/" class="link-kumya"><span data-letters="Join Us">Join Us</span></a></li>
								<li><a href="admin/" class="link-kumya"><span data-letters="Staff">Staff</span></a></li>
							</ul>	
							<div class="clearfix"> </div>
						</div>
					</div>
				</nav>
			</div>	
			<!--//navigation-->
			<div class="banner-text">
				<h2>WE'LL HELP YOU FIND YOUR DREAM HOME</h2>
			</div>	
		</div>
	</div>
	<!--//banner-->
	<!--blog-->
	<div class="blog">
		<div class="container">
			<h3 class="title">Our Blog </h3>
			<div class="blog-info">
				<div class="col-md-6 blog-grids">
					<div class="blog-img">
						<a href="single.html"> <img src="images/g6.jpg" class="img-responsive zoom-img" alt=""/></a>
					</div>
					<h4><a href="single.html">Fringilla condi me ntum consectetur</a></h4>
					<p class="snglp">Posted By<a href="#"> Admin</a> &nbsp;&nbsp;on  January 30, 2016 &nbsp;&nbsp; <a href="#">Comments (10)</a></p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor If you are going to use a passage	There are many variations of passages of Lorem Ipsum available, but the majority have suffered </p>
					<div class="more more2">
						<a href="single.html" class="button-pipaluk button--inverted"> Read More</a>
					</div>
				</div>
				<div class="col-md-6 blog-grids">
					<div class="blog-img">
						<a href="single.html"> <img src="images/g8.jpg" class="img-responsive zoom-img" alt=""/></a>
					</div>
					<h4><a href="single.html">Consectetur fringilla condi me ntum </a></h4>
					<p class="snglp">Posted By<a href="#"> Admin</a> &nbsp;&nbsp;on  February 03, 2016 &nbsp;&nbsp; <a href="#">Comments (10)</a></p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor If you are going to use a passage	There are many variations of passages of Lorem Ipsum available, but the majority have suffered </p>
					<div class="more more2">
						<a href="single.html" class="button-pipaluk button--inverted"> Read More</a>
					</div>
				</div>
				<div class="col-md-6 blog-grids">
					<div class="blog-img">
						<a href="single.html"> <img src="images/g2.jpg" class="img-responsive zoom-img" alt=""/></a>
					</div>
					<h4><a href="single.html">Qonsectetur fringilla condi me ntum </a></h4>
					<p class="snglp">Posted By<a href="#"> Admin</a> &nbsp;&nbsp;on  February 10, 2016 &nbsp;&nbsp; <a href="#">Comments (10)</a></p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor If you are going to use a passage	There are many variations of passages of Lorem Ipsum available, but the majority have suffered </p>
					<div class="more more2">
						<a href="single.html" class="button-pipaluk button--inverted"> Read More</a>
					</div>
				</div>
				<div class="col-md-6 blog-grids">
					<div class="blog-img">
						<a href="single.html"> <img src="images/g7.jpg" class="img-responsive zoom-img" alt=""/></a>
					</div>
					<h4><a href="single.html">Fringilla consectetur condi me ntum </a></h4>
					<p class="snglp">Posted By<a href="#"> Admin</a> &nbsp;&nbsp;on  February 20, 2016 &nbsp;&nbsp; <a href="#">Comments (10)</a></p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor If you are going to use a passage	There are many variations of passages of Lorem Ipsum available, but the majority have suffered </p>
					<div class="more more2">
						<a href="single.html" class="button-pipaluk button--inverted"> Read More</a>
					</div>
				</div>
				<div class="col-md-6 blog-grids">
					<div class="blog-img">
						<a href="single.html"> <img src="images/g4.jpg" class="img-responsive zoom-img" alt=""/></a>
					</div>
					<h4><a href="single.html">Sednsectetur condi me ntum fringilla </a></h4>
					<p class="snglp">Posted By<a href="#"> Admin</a> &nbsp;&nbsp;on  march 02, 2016 &nbsp;&nbsp; <a href="#">Comments (10)</a></p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor If you are going to use a passage	There are many variations of passages of Lorem Ipsum available, but the majority have suffered </p>
					<div class="more more2">
						<a href="single.html" class="button-pipaluk button--inverted"> Read More</a>
					</div>
				</div>
				<div class="col-md-6 blog-grids">
					<div class="blog-img">
						<a href="single.html"> <img src="images/g5.jpg" class="img-responsive zoom-img" alt=""/></a>
					</div>
					<h4><a href="single.html">Secteturcon fringilla condi mentum </a></h4>
					<p class="snglp">Posted By<a href="#"> Admin</a> &nbsp;&nbsp;on  march 09, 2016 &nbsp;&nbsp; <a href="#">Comments (10)</a></p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor If you are going to use a passage	There are many variations of passages of Lorem Ipsum available, but the majority have suffered </p>
					<div class="more more2">
						<a href="single.html" class="button-pipaluk button--inverted"> Read More</a>
					</div>
				</div>
				<div class="clearfix"> </div>
				
	
			</div>	
		</div>	
	</div>	
	<!--//blog-->
	<!--footer-->

	<?php include("includes/footer.php")?>
	<!--//footer-->
	<!-- script-for prettySticky -->
	<script src="js/prettySticky.js"></script>
	<!--//script-for prettySticky -->
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>
</body>
</html>
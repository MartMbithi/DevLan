<footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <?php echo date ("Y");?> <strong>RHMS</strong>. All Rights Reserved
        </p>
        <div class="credits">
          Powered By  <a href="https://martdev.info">MartDevelopers</a>
        </div>
        <a href="index.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
</footer>
<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="martdev1_rhms";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>

# rhms
Rental house management System with core php(no framework)

 admin dashboard
 #email:martdevelopers254@gmail.com password: demo
 ![admin dashboard](https://github.com/MartMbithi/rhms/blob/master/blob1.png)
 
  client dashboard
 ![client dashboard](https://github.com/MartMbithi/rhms/blob/master/blob2.png)

how to run:
download the project either by git cloning or as a zip and extract it to htdocs folder in your machine
in browser type http://127.0.0.1/RHMS/ 


enjoy :)
